﻿namespace USBApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.treeViewUSB = new System.Windows.Forms.TreeView();
            this.textBoxFileContent = new System.Windows.Forms.TextBox();
            this.btnSaveFile = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnAddTextFile = new System.Windows.Forms.Button();
            this.btnAddFolder = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();

            // 
            // treeViewUSB
            // 
            this.treeViewUSB.Location = new System.Drawing.Point(12, 35);
            this.treeViewUSB.Name = "treeViewUSB";
            this.treeViewUSB.Size = new System.Drawing.Size(300, 400);
            this.treeViewUSB.TabIndex = 0;
            this.treeViewUSB.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeViewUSB_AfterSelect);

            // 
            // textBoxFileContent
            // 
            this.textBoxFileContent.Location = new System.Drawing.Point(330, 35);
            this.textBoxFileContent.Multiline = true;
            this.textBoxFileContent.Name = "textBoxFileContent";
            this.textBoxFileContent.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxFileContent.Size = new System.Drawing.Size(450, 250);
            this.textBoxFileContent.TabIndex = 1;

            // 
            // btnSaveFile
            // 
            this.btnSaveFile.Location = new System.Drawing.Point(330, 300);
            this.btnSaveFile.Name = "btnSaveFile";
            this.btnSaveFile.Size = new System.Drawing.Size(100, 30);
            this.btnSaveFile.TabIndex = 2;
            this.btnSaveFile.Text = "Guardar Archivo";
            this.btnSaveFile.UseVisualStyleBackColor = true;
            this.btnSaveFile.Click += new System.EventHandler(this.btnSaveFile_Click);

            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(680, 300);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(100, 30);
            this.btnRefresh.TabIndex = 3;
            this.btnRefresh.Text = "Refrescar";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);

            // 
            // btnAddTextFile
            // 
            this.btnAddTextFile.Location = new System.Drawing.Point(450, 350);
            this.btnAddTextFile.Name = "btnAddTextFile";
            this.btnAddTextFile.Size = new System.Drawing.Size(150, 30);
            this.btnAddTextFile.TabIndex = 4;
            this.btnAddTextFile.Text = "Añadir Archivo de Texto";
            this.btnAddTextFile.UseVisualStyleBackColor = true;
            this.btnAddTextFile.Click += new System.EventHandler(this.btnAddTextFile_Click);

            // 
            // btnAddFolder
            // 
            this.btnAddFolder.Location = new System.Drawing.Point(450, 400);
            this.btnAddFolder.Name = "btnAddFolder";
            this.btnAddFolder.Size = new System.Drawing.Size(150, 30);
            this.btnAddFolder.TabIndex = 5;
            this.btnAddFolder.Text = "Añadir Carpeta";
            this.btnAddFolder.UseVisualStyleBackColor = true;
            this.btnAddFolder.Click += new System.EventHandler(this.btnAddFolder_Click);

            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(223, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Seleccione una unidad USB para explorarla:";

            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnAddFolder);
            this.Controls.Add(this.btnAddTextFile);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.btnSaveFile);
            this.Controls.Add(this.textBoxFileContent);
            this.Controls.Add(this.treeViewUSB);
            this.Name = "Form1";
            this.Text = "USB File Manager";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.TreeView treeViewUSB;
        private System.Windows.Forms.TextBox textBoxFileContent;
        private System.Windows.Forms.Button btnSaveFile;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnAddTextFile;
        private System.Windows.Forms.Button btnAddFolder;
        private System.Windows.Forms.Label label1;
    }
}
