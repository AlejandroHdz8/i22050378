﻿using System;
using System.IO;
using System.Windows.Forms;

namespace USBApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            LoadUSBDrives(); 
            WatchForUSBChanges(); 
        }

        private FileSystemWatcher usbWatcher;

        private void LoadUSBDrives()
        {
            treeViewUSB.Nodes.Clear();
            foreach (var drive in DriveInfo.GetDrives())
            {
                if (drive.DriveType == DriveType.Removable && drive.IsReady)
                {
                    TreeNode rootNode = new TreeNode(drive.Name)
                    {
                        Tag = drive.RootDirectory.FullName
                    };
                    treeViewUSB.Nodes.Add(rootNode);
                    LoadDirectoriesAndFiles(rootNode);
                }
            }
        }

        private void LoadDirectoriesAndFiles(TreeNode node)
        {
            try
            {
                string path = node.Tag.ToString();

                foreach (var dir in Directory.GetDirectories(path))
                {
                    TreeNode dirNode = new TreeNode(Path.GetFileName(dir))
                    {
                        Tag = dir
                    };
                    node.Nodes.Add(dirNode);
                }

                foreach (var file in Directory.GetFiles(path))
                {
                    TreeNode fileNode = new TreeNode(Path.GetFileName(file))
                    {
                        Tag = file
                    };
                    node.Nodes.Add(fileNode);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar directorios y archivos: " + ex.Message);
            }
        }

        private void treeViewUSB_AfterSelect(object sender, TreeViewEventArgs e)
        {
            string selectedPath = e.Node.Tag.ToString();

            if (File.Exists(selectedPath))
            {
                try
                {
                    textBoxFileContent.Text = File.ReadAllText(selectedPath);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al leer el archivo: " + ex.Message);
                }
            }
            else
            {
                textBoxFileContent.Clear();
            }
        }

        private void btnSaveFile_Click(object sender, EventArgs e)
        {
            if (treeViewUSB.SelectedNode == null)
            {
                MessageBox.Show("Seleccione una carpeta para guardar el archivo.");
                return;
            }

            string selectedPath = treeViewUSB.SelectedNode.Tag.ToString();

            if (!Directory.Exists(selectedPath))
            {
                MessageBox.Show("Seleccione una carpeta válida.");
                return;
            }

            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                InitialDirectory = selectedPath,
                Filter = "Archivos de texto (*.txt)|*.txt",
                Title = "Guardar archivo de texto"
            };

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    File.WriteAllText(saveFileDialog.FileName, textBoxFileContent.Text);
                    MessageBox.Show("Archivo guardado exitosamente.");
                    treeViewUSB.SelectedNode.Nodes.Clear();
                    LoadDirectoriesAndFiles(treeViewUSB.SelectedNode);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al guardar el archivo: " + ex.Message);
                }
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadUSBDrives();
        }

        private void btnAddTextFile_Click(object sender, EventArgs e)
        {
            if (treeViewUSB.SelectedNode == null)
            {
                MessageBox.Show("Seleccione una carpeta para añadir el archivo de texto.");
                return;
            }

            string selectedPath = treeViewUSB.SelectedNode.Tag.ToString();

            if (!Directory.Exists(selectedPath))
            {
                MessageBox.Show("Seleccione una carpeta válida.");
                return;
            }

            string fileName = PromptForInput("Ingrese el nombre del archivo de texto (sin extensión):", "Nuevo Archivo de Texto");
            if (string.IsNullOrWhiteSpace(fileName)) return;

            string newFilePath = Path.Combine(selectedPath, fileName + ".txt");

            try
            {
                string content = PromptForInput("Escriba el contenido inicial del archivo:", "Contenido del Archivo");
                File.WriteAllText(newFilePath, content);
                MessageBox.Show("Archivo de texto creado exitosamente.");
                treeViewUSB.SelectedNode.Nodes.Clear();
                LoadDirectoriesAndFiles(treeViewUSB.SelectedNode);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al crear el archivo de texto: " + ex.Message);
            }
        }

        private void btnAddFolder_Click(object sender, EventArgs e)
        {
            if (treeViewUSB.SelectedNode == null)
            {
                MessageBox.Show("Seleccione una carpeta para añadir una nueva carpeta.");
                return;
            }

            string selectedPath = treeViewUSB.SelectedNode.Tag.ToString();

            if (!Directory.Exists(selectedPath))
            {
                MessageBox.Show("Seleccione una carpeta válida.");
                return;
            }

            string folderName = PromptForInput("Ingrese el nombre de la nueva carpeta:", "Nueva Carpeta");
            if (string.IsNullOrWhiteSpace(folderName)) return;

            string newFolderPath = Path.Combine(selectedPath, folderName);

            try
            {
                Directory.CreateDirectory(newFolderPath);
                MessageBox.Show("Carpeta creada exitosamente.");
                treeViewUSB.SelectedNode.Nodes.Clear();
                LoadDirectoriesAndFiles(treeViewUSB.SelectedNode);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al crear la carpeta: " + ex.Message);
            }
        }

        private string PromptForInput(string prompt, string title)
        {
            using (Form inputForm = new Form())
            {
                inputForm.Width = 400;
                inputForm.Height = 150;
                inputForm.Text = title;

                Label lblPrompt = new Label() { Left = 10, Top = 10, Text = prompt, Width = 360 };
                TextBox txtInput = new TextBox() { Left = 10, Top = 40, Width = 360 };
                Button btnOk = new Button() { Text = "OK", Left = 200, Width = 80, Top = 80, DialogResult = DialogResult.OK };
                Button btnCancel = new Button() { Text = "Cancelar", Left = 290, Width = 80, Top = 80, DialogResult = DialogResult.Cancel };

                inputForm.Controls.Add(lblPrompt);
                inputForm.Controls.Add(txtInput);
                inputForm.Controls.Add(btnOk);
                inputForm.Controls.Add(btnCancel);
                inputForm.AcceptButton = btnOk;
                inputForm.CancelButton = btnCancel;

                return inputForm.ShowDialog() == DialogResult.OK ? txtInput.Text : null;
            }
        }

        private void WatchForUSBChanges()
        {
            usbWatcher = new FileSystemWatcher
            {
                Path = "C:\\",
                NotifyFilter = NotifyFilters.DirectoryName | NotifyFilters.FileName | NotifyFilters.Attributes,
                Filter = "*.*"
            };

            usbWatcher.Created += (sender, args) => { Invoke(new Action(LoadUSBDrives)); };
            usbWatcher.Deleted += (sender, args) => { Invoke(new Action(LoadUSBDrives)); };

            usbWatcher.EnableRaisingEvents = true;
        }
    }
}
